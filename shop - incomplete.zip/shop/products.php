<?php require __DIR__ . "/inc/header.php"; ?>
     
   <h1>Products!</h1>

<?php require __DIR__ . "/inc/footer.php"; ?>