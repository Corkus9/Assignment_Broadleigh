<?php $title = 'Register Page'; require __DIR__ . "/inc/header.php"; ?>
     
<?php require __DIR__ . "/components/reg-form.php"; ?>

<?php require __DIR__ . "/inc/footer.php"; ?>