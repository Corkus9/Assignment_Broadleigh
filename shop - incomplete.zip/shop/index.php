<?php require __DIR__ . "/inc/header.php"; ?>
     
   <h1>Welcome!</h1>

<?php require __DIR__ . "/inc/footer.php"; ?>